function Flight(email, resNo, cityFrom, cityTo) {
    this.email = email;
    this.resNo = resNo;
    this.cityFrom = cityFrom;
    this.cityTo = cityTo;
}

var flights = [];

flights.push(new Flight("andrius.olisauskas@mail1.com", 123451, "Vilnius", "Auckland"));
flights.push(new Flight("andrius.olisauskas@mail2.com", 123452, "Kaunas", "Pisa"));
flights.push(new Flight("andrius.olisauskas@mail3.com", 123453, "Warsaw", "Toronto"));
flights.push(new Flight("andrius.olisauskas@mail4.com", 123454, "Barcelona", "San Jose"));

var rf = document.querySelector("#reservationForm");

rf.addEventListener('submit', (e) => {
    e.preventDefault();
    let rfEmail = e.target["inputEmail"].value.trim();
    let rfNumber = parseInt(e.target["inputReservation"].value);

    checkReservation(rfEmail, rfNumber);
    rf.reset();
});

function checkReservation(email, number) {
    for (let i = 0; i < flights.length; i++) {
        if (flights[i]["email"] == email && flights[i]["resNo"] == number) {
            alert(flights[i]["cityFrom"] + " to " + flights[i]["cityTo"]);
            break;
        } else if ((i == flights.length - 1) && (flights[i]["email"] !== email || flights[i]["resNo"] !== number)) {
            alert("Please check email and reservation number");
        }
    }

}
