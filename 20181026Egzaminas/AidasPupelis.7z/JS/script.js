function Flight(email, code, townFrom, townTo) {
    this.email = email;
    this.code = code;
    this.townFrom = townFrom;
    this.townTo = townTo;
}

var flight = [];

var.parent = document.querySelector("#flightParent");

flight.push(new Flight("jonas.jonaitis@gmail.com", 123456, "Vilnius", "Barcelona"));
flight.push(new Flight("toma.tomauskaite@gmail.com", 956484, "Vilnius", "Barcelona"));
flight.push(new Flight("petras.petraitis@gmail.com", 542877, "Vilnius", "Barcelona"));

function searchBy() {
    parent.innerHTML = "";
    let searchBy = document.querySelector("#searchBy").value;
    let searchFor = document.querySelector("#searchFor").value;
    
    
    if () {
        
        } else {
        
        }
}
